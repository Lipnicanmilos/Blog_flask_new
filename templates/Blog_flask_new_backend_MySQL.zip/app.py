from enum import unique
from logging import debug
from os import name
from sys import executable
from MySQLdb import cursors
from MySQLdb.cursors import Cursor
from flask import Flask, render_template, request, redirect, url_for, session, flash
from flask_mysqldb import MySQL, MySQLdb
from datetime import datetime
from flask_login import login_user, logout_user, login_required, current_user
from DateTime import DateTime
from flask_sqlalchemy import SQLAlchemy

# toto mu hovorí kde ma začať 
app = Flask(__name__)
app.secret_key ="toto_je_jedno"

app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///mydb.sqlite'
mydb = SQLAlchemy(app)


# databaza
app.config['MYSQL_HOST'] = 'sql4.freemysqlhosting.net'
app.config['MYSQL_USER'] = 'sql4440817'
app.config['MYSQL_PASSWORD'] = 'kvRgYy1jSw'
app.config['MYSQL_DB'] = 'sql4440817'
mysql = MySQL(app)

@app.route("/")
@app.route("/home")
def index():
    return render_template('index.html')


# užívatelia ----------------------------------------------------------------------------------------------
@app.route("/users")
#@login_required
def users():
    if session['email'] == 'dominika.babinska@gmail.com' or session['email'] == 'lipnicanmilos@gmail.com':
        cur = mysql.connection.cursor()
        cur.execute("SELECT * FROM DL_users")
        data = cur.fetchall()
        cur.close()

        return render_template('users.html', users = data)

@app.route('/update',methods=['POST','GET'])
def update():

    if request.method == 'POST':
        id_data = request.form['id']
        name = request.form['name']
        email = request.form['email']
        mobil = request.form['mobil']
        password = request.form['password'].encode('utf-8')
        cur = mysql.connection.cursor()
        cur.execute("""
               UPDATE DL_users
               SET name=%s, email=%s, mobil=%s, password=%s
               WHERE id=%s
            """, (name, email, mobil, password, id_data))
        flash("Všetky zmeny boli uložené")
        mysql.connection.commit()
        cur.close()

        return redirect(url_for('users'))

@app.route('/delete/<string:id_data>', methods = ['GET'])
def delete(id_data):
    
    cur = mysql.connection.cursor()
    cur.execute("DELETE FROM DL_users WHERE id=%s", (id_data,))
    mysql.connection.commit()
    cur.close()
    
    flash("užívateľ bol úspešne vymazaný zo zoznamu")
    
    return redirect(url_for('users'))
# ----------------------------------------------------------------------------------------------


@app.route('/pozdrav/<meno>')
def pozdrav(meno):
    return render_template('pozdrav.html', meno2=meno)

@app.route('/register', methods=["GET", "POST"])
def register():

    error = None
    success = None
    

    if request.method == "POST":
        name = request.form['name']
        email = request.form['email'] 
        mobil = request.form['mobil']
        password = request.form['password'].encode('utf-8')
        password2 = request.form['password2'].encode('utf-8')


        # porovnanie emailu s datami v db(emaily) a ukiženie v exstingInfo
        cur = mysql.connection.cursor()
        cur.execute("SELECT * FROM DL_users WHERE email=%s", (email,))
        existingInfo = cur.fetchone()
        
        
        if len(name) < 1:
            error = "Musíš zadať meno"
        
        elif len(email) < 1:
            error = "Musíš zadať email"

        elif len(password) < 1:
            error = "Musíš zadať heslo"
        
        elif password != password2:
            error = "heslo musí byť rovnaké"

        elif len(password) < 4:
            error = "Tvoje heslo má menej ako 4 znaky"
        
        elif existingInfo is not None:
            error = "Tento email je už zaregistrovaný" 
            
        else:
            cur = mysql.connection.cursor()     
            sql = "INSERT INTO DL_users (name, email, mobil, password) VALUES (%s, %s, %s, %s)"
            val = (name, email, mobil, password)
            cur.execute(sql, val)

            mysql.connection.commit()
            cur.close()

            success = "Si úspešne zaregistrovaný môžeš sa prihlásiť"
            return render_template('login.html', msg=success)    

    return render_template('register.html', error=error)

@app.route('/login', methods=['GET','POST'])
def login():
    # Output message if something goes wrong...
    msg = ''
    # Check if "username" and "password" POST requests exist (user submitted form)
    if request.method == 'POST' and 'email' in request.form and 'password' in request.form:
        # Create variables for easy access
        email = request.form['email']
        password = request.form['password']
        # Check if account exists using MySQL
        cursor = mysql.connection.cursor(MySQLdb.cursors.DictCursor)
        cursor.execute('SELECT * FROM DL_users WHERE email = %s AND password = %s', (email, password,))
        # Fetch one record and return result
        account = cursor.fetchone()
        # If account exists in accounts table in out database
        if account:
            # Create session data, we can access this data in other routes
            session['loggedin'] = True
            session['id'] = account['id']
            session['name'] = account['name']
            session['email'] = account['email']
            # Redirect to home page
            flash("Si prihlasený/á")
            return render_template('index.html')
        else:
            # Account doesnt exist or username/password incorrect
            msg = 'Nesprávny email/heslo!'
    # Show the login form with message (if any)
    return render_template('login.html', msg=msg)

@app.route('/logout')
def logout():
    session.clear()
    return render_template("login.html")


@app.route('/base')
def base():
    def_time = datetime.now()
    return render_template('base.html',  def_time=def_time)
    
@app.route('/table')
@login_required
def table():
    return render_template('table.html')


# hosting python https://www.pythonanywhere.com/details/flask_hosting
# hosting pythonm https://www.youtube.com/watch?v=xTn4DXI8dyc
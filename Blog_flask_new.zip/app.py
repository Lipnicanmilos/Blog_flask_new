from enum import unique
from logging import debug
from os import name
from sys import executable
from MySQLdb import cursors
from MySQLdb.cursors import Cursor
from flask import Flask, render_template, request, redirect, url_for, session, flash
from flask_mysqldb import MySQL, MySQLdb
from datetime import datetime
from flask_login import login_manager, login_user, logout_user, login_required, current_user, LoginManager
from DateTime import DateTime
from flask_sqlalchemy import SQLAlchemy
import sqlite3
from werkzeug.security import check_password_hash, generate_password_hash

 

# toto mu hovorí kde ma začať 
app = Flask(__name__)
app.secret_key ="toto_je_jedno"
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///sqlite.db'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
db = SQLAlchemy(app)

from models import User

# databaza
# app.config['MYSQL_HOST'] = 'sql4.freemysqlhosting.net'
# app.config['MYSQL_USER'] = 'sql4440817'
# app.config['MYSQL_PASSWORD'] = 'kvRgYy1jSw'
# app.config['MYSQL_DB'] = 'sql4440817'
# mysql = MySQL(app) 

# login_manager = LoginManager()
# login_manager.init_app(app)
# login_manager.login_view = 'login'

# @login_manager.user_loader
# def load_user(id):
#     return User.query.get(int(email))



@app.route("/")
@app.route("/home")
def index():
    return render_template('index.html')

#registrácia usera do db 
#-----------------------------------------
@app.route("/register", methods=["GET", "POST"])
def register():

    error = None
    success = None
    
    #check the request method to ensure the handling of POST request only
    if request.method == "POST":
        #store the form value
        name = request.form["name"]
        email = request.form["email"]
        password = request.form["password"]
        password2 = request.form["password2"]

        # porovnanie emailu s datami v db(emaily) a ukiženie v exstingInfo
        conn = sqlite3.connect('sqlite.db') 
        c = conn.cursor()
        c.execute("SELECT * from user where email = (?)", [email])
        existingInfo = c.fetchone()
        con = conn.cursor()
        con.execute("SELECT * from user where username = (?)", [name])
        existingInfo1 = con.fetchone()
        

        if len(name) < 1:
            error = "Musíš zadať meno"
        
        elif len(email) < 1:
            error = "Musíš zadať email"

        elif len(password) < 1:
            error = "Musíš zadať heslo"
        
        elif password != password2:
            error = "heslo musí byť rovnaké"

        elif len(password) < 4:
            error = "Tvoje heslo má menej ako 4 znaky"
        
        elif existingInfo is not None:
            error = "Tento email je už zaregistrovaný" 
        
        elif existingInfo1 is not None:
            error = "Už existuje užívateľ s týmto menom" 

        else:        
            # store the user details in the user database table
            user = User()
            user.username = name
            user.email = email
            user.set_password(password)
            
            # add the user object to the database
            db.session.add(user)

            
            session["name"] = name
            session["id"] = user.id
            session["email"] = user.email

            # commit changes to the database 
            db.session.commit()
            
            flash("Vytvorili ste si účet")
            return redirect(url_for('index'))

    return render_template('register.html', error=error)
# --------------------------------------

# užívatelia ----------------------------------------------------------------------------------------------
@app.route('/users')
def users():
    conn = sqlite3.connect('sqlite.db') 
    c = conn.cursor()
    c.execute('SELECT * FROM user')    
    return render_template('users.html', rows = c.fetchall())

# update - uživatela
# -------------------------------------------------------------
@app.route('/update',methods=['POST','GET'])
def update():

    if request.method == 'POST':
        id_data = request.form['id']
        name = request.form['name']
        email = request.form['email']
        password = request.form['password']

        conn = sqlite3.connect('sqlite.db') 
        c = conn.cursor()
        c.execute("""UPDATE user SET username=(?), email=(?), password=(?) WHERE id=(?)""", (name, email, password, id_data))
        flash("Všetky zmeny boli uložené")
        c.connection.commit()
        c.close()

        return redirect(url_for('users'))

# delete - uživatela
# -------------------------------------------------------------
@app.route('/delete/<string:id_data>', methods = ['GET'])
def delete(id_data):
    
    conn = sqlite3.connect('sqlite.db') 
    c = conn.cursor()
    c.execute("DELETE FROM user WHERE id=(?)", (id_data))
    c.connection.commit()
    c.close()

    
    flash("užívateľ bol úspešne vymazaný zo zoznamu")
    
    return redirect(url_for('users'))

# login uživateľa
# -----------------------------------------------------
@app.route("/login", methods=["GET", "POST"])
def login():
    if "name" in session:
        return redirect(url_for('index'))
    flash("Ste prihlásený")
    error = False
    if request.method == "POST":
        email = request.form.get("email")
        password = request.form.get("password")

        user = User.query.filter_by(email=email).first()
        if user:
            if user.check_password(password):
                session["name"] = user.username
                session["id"] = user.id
                session["email"] = user.email
                return redirect("/")
            else:
                error = "Email alebo heslo je nespravne."
        else:
            error = "Email alebo heslo je nespravne."
    return render_template("login.html", error=error)


# logout uživateľa
# -----------------------------------------------------
@app.route('/logout')
def logout():
    session.clear()
    return render_template("login.html")


@app.route('/base')
def base():
    def_time = datetime.now()
    return render_template('base.html',  def_time=def_time)
    
@app.route('/table')
@login_required
def table():
    return render_template('table.html')

# @login_manager.user_loader
# def load_user(user_id):
#      return User.get(User.id == user_id)

@app.route("/moje_meno")
def moje_meno():
    if "name" not in session:
        return "nie si prihlaseny"
    return str(session["id"]) + ", ...  " + session["name"] + ", ...  " + session["email"]


if __name__ == '__main__':
    app.run()

# hosting python https://www.pythonanywhere.com/details/flask_hosting
# hosting pythonm https://www.youtube.com/watch?v=xTn4DXI8dyc